// ============================================================
// CONFIGURACIÓN DE LA TIENDA
// Cambiá estos datos por los reales de tu emprendimiento.
// ============================================================
const STORE_CONFIG = {
  name: "Luz de Cera",
  tagline: "Velas y aromas hechos a mano en Córdoba",
  heroTitle: "Cada vela cuenta una historia distinta.",
  heroCopy:
    "Elaboramos velas de soja, difusores y jabones artesanales en pequeños lotes, con aromas propios y materiales naturales.",

  // Número de WhatsApp con código de país, SIN "+", espacios ni guiones.
  // Ejemplo Argentina (celular): 549 + código de área + número.
  // Córdoba capital sería algo como "5493511234567".
  whatsappNumber: "5493511234567",

  instagram: "https://instagram.com/tuemprendimiento",
  currency: "$",
  footerLocation: "Córdoba, Argentina",
};

// ============================================================
// PRODUCTOS
// Copiá un bloque { ... } completo para agregar un producto nuevo
// y pegalo dentro de los corchetes, separado por una coma.
//
// Campos:
//   id          identificador único, sin espacios (ej: "vela-lavanda")
//   name        nombre visible del producto
//   category    categoría; los filtros de arriba se arman solos
//               a partir de las categorías que uses acá
//   price       precio en números, sin puntos ni el símbolo $
//   description texto corto, una oración alcanza
//   image       ruta a la foto dentro de /images
//               (si el archivo todavía no existe, se muestra
//               un ícono automáticamente — podés cargar productos
//               antes de tener las fotos listas)
// ============================================================
const PRODUCTS = [
  {
    id: "vela-lavanda-romero",
    name: "Vela lavanda y romero",
    category: "Velas",
    price: 8500,
    description: "Vela de soja en frasco de vidrio, combustión aprox. 40 hs.",
    image: "images/vela-lavanda-romero.jpg",
  },
  {
    id: "vela-vainilla-madera",
    name: "Vela vainilla y madera",
    category: "Velas",
    price: 8500,
    description: "Aroma cálido y amaderado, mecha de algodón.",
    image: "images/vela-vainilla-madera.jpg",
  },
  {
    id: "vela-mini-citricos",
    name: "Vela mini cítricos",
    category: "Velas",
    price: 4200,
    description: "Formato viajero, ideal para regalar.",
    image: "images/vela-mini-citricos.jpg",
  },
  {
    id: "difusor-eucalipto",
    name: "Difusor de eucalipto",
    category: "Difusores",
    price: 9800,
    description: "Difusor de varillas, 120 ml, dura entre 6 y 8 semanas.",
    image: "images/difusor-eucalipto.jpg",
  },
  {
    id: "difusor-flor-naranjo",
    name: "Difusor de flor de naranjo",
    category: "Difusores",
    price: 9800,
    description: "Aroma floral suave, incluye varillas de ratán.",
    image: "images/difusor-flor-naranjo.jpg",
  },
  {
    id: "jabon-avena-miel",
    name: "Jabón de avena y miel",
    category: "Jabones",
    price: 3200,
    description: "Jabón artesanal exfoliante, apto piel sensible.",
    image: "images/jabon-avena-miel.jpg",
  },
  {
    id: "jabon-carbon-activado",
    name: "Jabón de carbón activado",
    category: "Jabones",
    price: 3200,
    description: "Jabón purificante para piel mixta a grasa.",
    image: "images/jabon-carbon-activado.jpg",
  },
  {
    id: "kit-relax",
    name: "Kit relax",
    category: "Kits",
    price: 15800,
    description: "Vela + jabón + difusor mini, presentación para regalo.",
    image: "images/kit-relax.jpg",
  },
  {
    id: "kit-bienvenida",
    name: "Kit bienvenida hogar",
    category: "Kits",
    price: 17500,
    description: "Ideal para inauguraciones: vela grande + difusor + tarjeta.",
    image: "images/kit-bienvenida.jpg",
  },
];
